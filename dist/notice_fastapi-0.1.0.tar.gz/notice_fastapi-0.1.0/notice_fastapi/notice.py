from pydantic import BaseModel
from datetime import datetime

class Notice(BaseModel):
    id : int
    title : str
    content : str 
    # create_date : datetime