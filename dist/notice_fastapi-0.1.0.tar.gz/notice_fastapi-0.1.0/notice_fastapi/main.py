from inmemory import NoticeDB
from notice import Notice
from fastapi import FastAPI
from dependency_injector import Provide, inject
 
app = FastAPI()

@app.get("/")
async def root():
    return {"message" : "Hello"}

@app.post("/create_notice")
async def create_notice(notice : Notice):
        # notice_list = Singleton(NoticeDB)

    return notice

@app.get("/get_list")
async def get_list():
    
    return ""

@app.get("/get_notice")
async def get_notice():
    return ""
