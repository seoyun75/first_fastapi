# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['notice_fastapi']

package_data = \
{'': ['*']}

install_requires = \
['dependency-injector>=4.37.0,<5.0.0', 'fastapi>=0.92.0,<0.93.0']

setup_kwargs = {
    'name': 'notice-fastapi',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'seoyun75',
    'author_email': '67564166+seoyun75@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
