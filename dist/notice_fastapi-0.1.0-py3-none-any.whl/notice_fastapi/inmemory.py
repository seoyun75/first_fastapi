from notice import Notice

class NoticeDB():
    notice_list : list(dict[int, Notice])
    